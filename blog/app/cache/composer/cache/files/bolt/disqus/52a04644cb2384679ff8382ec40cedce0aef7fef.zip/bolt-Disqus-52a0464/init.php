<?php

use Bolt\Extension\Bolt\Disqus\Extension;

$app['extensions']->register(new Extension($app));
