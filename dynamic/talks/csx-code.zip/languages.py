import zipfile
import os
import itertools
import pprint
import numpy as np
import matplotlib.pyplot as plt
import scipy.cluster.hierarchy as hier
import scipy.spatial.distance as dist


dist_table = {}


class Dendrogram:

    def __init__(self, tree):
        self.tree = tree

    def locate(self, tree, depth, cnt):
        if isinstance(tree, str):
            return {'depth': depth, 'height': -next(cnt), 'inner': None, 'txt': tree}
        fn = lambda x: self.locate(x, depth+1, cnt)
        loc = [fn(x) for x in tree]
        height = np.mean([x['height'] for x in loc])
        return {'depth': depth, 'height': height, 'inner': loc, 'txt': None}

    def walk(self, loc, ax):
        col, lw = 'DarkBlue', 2
        x, y, inner, txt = map(loc.get, ['depth', 'height', 'inner', 'txt'])
        if not inner:
            ax.text(x, y, ' ' + txt, ha='left', va='center', size='large')
            return y
        else:
            ys =[self.walk(t, ax) for t in inner]
            for y1 in ys:
                ax.plot([x, x+1], [y1, y1], color=col, linewidth=lw)
            ax.plot([x, x], [min(ys), max(ys)], color=col, linewidth=lw)
            return y

    def draw(self):
        fig = plt.figure(figsize=(2, 3))
        ax = fig.add_axes([.05, .05, .9, .9])
        loc = self.locate(self.tree, 0, itertools.count())
        self.walk(loc, ax)
        plt.axis('off')
        xl, yl = ax.get_xlim(), ax.get_ylim()
        ax.set_xlim(xl[0] - .05, xl[1] + .05)
        ax.set_ylim(yl[0] - .05, yl[1] + .05)
        plt.show()


def load_languages():
    languages = []
    for filename in os.listdir("dohr"):
        if filename.endswith(".txt"):
            languages.append(filename.strip(".txt"))
    return languages


def get_text(language):
    f = open("dohr/{}.txt".format(language))
    text = f.read()
    f.close()
    return text


def tree_contains(tree, key):
    if tree == key:
        return True
    try:
        a, b = tree
    except ValueError:
        return False
    else:
        return tree_contains(a, key) or tree_contains(b, key)


def pop_cluster(language, clusters):
    found = None
    for cluster in clusters:
        if tree_contains(cluster, language):
            found = cluster
            break
    if found is not None:
        clusters.remove(found)
        return found
    return language


def iter_cluster(cluster):
    if isinstance(cluster, str):
        yield cluster
    else:
        a, b = cluster
        yield from iter_cluster(a)
        yield from iter_cluster(b)


def distance(groups):
    group1, group2 = groups
    count = 0
    dist_total = 0
    for language1 in iter_cluster(group1):
        for language2 in iter_cluster(group2):
            count += 1
            dist_total += dist_table[(language1, language2)]
    return dist_total / count


def cluster(languages):
    clusters = set(languages)
    while len(clusters) > 1:
        l1, l2 = min(itertools.combinations(clusters, 2),
                     key=distance)
        l1_cluster = pop_cluster(l1, clusters)
        l2_cluster = pop_cluster(l2, clusters)
        clusters.add((l1_cluster, l2_cluster))
    tree, = clusters
    return tree


def z(s):
    with open("scratch.txt", "w") as myfile:
        myfile.write(s)
    with zipfile.ZipFile("scratch.zip", "w", compression=zipfile.ZIP_BZIP2) as myzip:
        myzip.write("scratch.txt")
    size = os.path.getsize("scratch.zip")
    os.remove("scratch.zip")
    os.remove("scratch.txt")
    return size


def ncd(x, y):
    z_xy = z(x + y)
    z_x = z(x)
    z_y = z(y)
    return (z_xy - min({z_x, z_y}))/(max({z_x, z_y}))


languages = load_languages()
for language1, language2 in itertools.combinations(languages, 2):
    text1 = get_text(language1)
    text2 = get_text(language2)
    d = ncd(text1, text2)
    dist_table[(language1, language2)] = d
    dist_table[(language2, language1)] = d
tree = cluster(languages)
pprint.pprint(tree)
d = Dendrogram(tree)
d.draw()
